package com.example.bigmac.build_a_snowman;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends ActionBarActivity {
    // declare variables
    private Button buttonClickHappy, buttonClickMad;
    private EditText editTextTemprature, editTextCentimeters;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // give variables there ID
        buttonClickHappy = (Button) findViewById(R.id.buttonHappy);
        buttonClickMad = (Button) findViewById(R.id.buttonMad);
        editTextCentimeters = (EditText) findViewById(R.id.editTextCentimeters);
        editTextTemprature = (EditText) findViewById(R.id.editTextTemprature);

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void buttonClickHappy(View view) {
        //Getting value of string entered in editText field
        //Converting the string to an interger so it can
        // be used for comparing in statements
        String snow = String.valueOf(editTextCentimeters.getText());
        String temp = String.valueOf(editTextTemprature.getText());
        int tempInt =Integer.parseInt(temp);
        int snowInt =Integer.parseInt(snow);

        //If temperature is above 0 there can't be build a snowman
        //If temperature is below -15 it's to cold
        //If there is less then 10 cm snow there is not enough snow to build a snowman
        //If there is more then 150 cm snow there is to much snow to build a snowman
        //Otherwise you can build a snowman with Elsa

        if ( tempInt > 0 ){
            String answerTooHot = "Too bad it's to warm to build a snowman today.";
            Toast.makeText(this, answerTooHot, Toast.LENGTH_LONG).show();
        }
        else if ( tempInt < -15){
            String answerTooCold = "Too bad it's to cold to build a snowman today.";
            Toast.makeText(this, answerTooCold, Toast.LENGTH_LONG).show();
        }
        else if ( snowInt < 10 ){
            String answerNoSnow = "Too bad there is not enough snow to build a snowman today.";
            Toast.makeText(this, answerNoSnow, Toast.LENGTH_LONG).show();
        }
        else if ( snowInt > 150 ){
            String answerMuchSnow = "There is too much snow, you can't open the castle doors to " +
                    "go outside.";
            Toast.makeText(this, answerMuchSnow, Toast.LENGTH_LONG).show();
        }
        else{
            String answerYes = "Yes we can go build a snowman together with Else today!";
            Toast.makeText(this, answerYes, Toast.LENGTH_LONG).show();
        }

    }
    public void buttonClickMad(View view){

        //Getting value of string entered in editText field
        //Converting the string to an interger so it can
        // be used for comparing in statements

        String snow = String.valueOf(editTextCentimeters.getText());
        String temp = String.valueOf(editTextTemprature.getText());
        int tempInt =Integer.parseInt(temp);
        int snowInt =Integer.parseInt(snow);

        //If temperature is above 0 there can't be build a snowman
        //If temperature is below -15 it's to cold
        //If there is less then 10 cm snow there is not enough snow to build a snowman
        //If there is more then 150 cm snow there is to much snow to build a snowman
        //Otherwise you can build a snowman without Elsa the bitch is mad you know

        if ( tempInt > 0 ){
            String answerTooHot = "Too bad it's to warm to build a snowman today.";
            Toast.makeText(this, answerTooHot, Toast.LENGTH_LONG).show();
        }
        else if ( tempInt < -15){
            String answerTooCold = "Too bad it's to cold to build a snowman today.";
            Toast.makeText(this, answerTooCold, Toast.LENGTH_LONG).show();
        }
        else if ( snowInt < 10 ){
            String answerNoSnow = "Too bad there is not enough snow to build a snowman today.";
            Toast.makeText(this, answerNoSnow, Toast.LENGTH_LONG).show();
        }
        else if ( snowInt > 150 ){
            String answerMuchSnow = "There is too much snow, you can't open the castle doors to " +
                    "go outside.";
            Toast.makeText(this, answerMuchSnow, Toast.LENGTH_LONG).show();
        }
        else{
            String answerYes = "Yes we can go build a snowman but Elsa is mad so we have to build " +
                    "it alone :(.";
            Toast.makeText(this, answerYes, Toast.LENGTH_LONG).show();
        }

    }
}
